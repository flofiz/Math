/********************************************************/
/*                    projetMathbernstein.cc                          */
/********************************************************/
/*                                                       */
/********************************************************/ 


#include <stdlib.h>
#define Pi 3.141592654
#include <iostream>
#include <string>
#include <fstream>
using namespace std;


int main(int argc,char **argv)
{
    cout<<"Bonjour et bon travail"<<endl;
    return 0;
}
